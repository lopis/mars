/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/client.js":
/*!***********************!*\
  !*** ./src/client.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
eval("/* harmony import */ var _client_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./client/index.js */ \"./src/client/index.js\");\n\n\n(function () {\n\n    let socket //Socket.IO client\n\n    /**\n     * Binds Socket.IO and button events\n     */\n    function bind() {\n        socket.on(\"start\", () => {\n        });\n\n        socket.on(\"disconnect\", () => {\n        });\n\n        socket.on(\"error\", () => {\n        });\n    }\n\n    /**\n     * Client module init\n     */\n    function init() {\n        socket = io({ upgrade: false, transports: [\"websocket\"] });\n        bind();\n        (0,_client_index_js__WEBPACK_IMPORTED_MODULE_0__.initGame)();\n    }\n\n    window.addEventListener(\"load\", init, false);\n\n})();\n\n\n//# sourceURL=webpack://mars/./src/client.js?");

/***/ }),

/***/ "./src/client/constants.js":
/*!*********************************!*\
  !*** ./src/client/constants.js ***!
  \*********************************/
/***/ (() => {

eval("RED = \"#881f1a\"\nBLACK = \"black\"\ntilt = 0.43\nplanetSize = 0.4\nspeed = 0.2\ninitialPhase = 0.1\n\ncanvasHeight = window.innerHeight\ncanvasWidth = window.innerWidth\n\nstatusRefreshDelay = 10\n\n//# sourceURL=webpack://mars/./src/client/constants.js?");

/***/ }),

/***/ "./src/client/index.js":
/*!*****************************!*\
  !*** ./src/client/index.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"initGame\": () => (/* binding */ initGame)\n/* harmony export */ });\n/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants */ \"./src/client/constants.js\");\n/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_constants__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _js_graphics__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./js/graphics */ \"./src/client/js/graphics.js\");\n\n\n\non('halt', () => {\n  loop.stop()\n})\n\non('ready', () => {\n  loop.start()\n})\n\nconst initGame = () => {\n  ;(0,_js_graphics__WEBPACK_IMPORTED_MODULE_1__.initContext)()\n  initLoop()\n  initKeys()\n  initPointer()\n  emit('ready')\n}\n\n//# sourceURL=webpack://mars/./src/client/index.js?");

/***/ }),

/***/ "./src/client/js/graphics.js":
/*!***********************************!*\
  !*** ./src/client/js/graphics.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"initContext\": () => (/* binding */ initContext)\n/* harmony export */ });\n/* unused harmony exports context, getCanvasCenter */\nlet context\nconst initContext = () => {\n  const opts = init(canvas);\n  canvas = opts.canvas\n  context = opts.context\n\n  canvas.height = canvasHeight\n  canvas.width = canvasWidth\n\n  window.addEventListener('resize', () => {\n    canvas.height = canvas.clientHeight\n    canvas.width = canvas.clientWidth\n  })\n}\n\nconst getCanvasCenter = () => {\n  return {\n    x: canvas.width / 2,\n    y: canvas.height / 2,\n  }\n}\n\n\n\n//# sourceURL=webpack://mars/./src/client/js/graphics.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./src/client.js");
/******/ 	
/******/ })()
;